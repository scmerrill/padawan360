#ifndef __DYSOUND_H__
#define __DYSOUND_H__

#include <Arduino.h>

class DYPlayer
{
    public:
        explicit DYPlayer();

        virtual void init();
        virtual void setup();
        void setup(HardwareSerial* serial);

        virtual void SetVolume(const byte Volume, const bool SetAsStandard = true);
        virtual void VolumeUp();
        virtual void VolumeDown();
        virtual void VolumeMid();
        virtual void VolumeMax();
        virtual void VolumeMin();
        virtual void VolumeOff();

        virtual void Play(const int track);
        virtual void Stop();
        virtual void Quiet(const bool on = true);

        virtual bool hasVocalizer()  { return false; }

    protected:
        HardwareSerial* s;
        void sendCommand(const byte* Command, const byte len);

    private:
        byte CurrentVolume;
};

#endif // __DYSOUND_H__