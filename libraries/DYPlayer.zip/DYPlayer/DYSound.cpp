#include "DYSound.h"


DYPlayer::DYPlayer()
{
    CurrentVolume = 15; // Medium Volume
}

void DYPlayer::setup()
{
	setup(&Serial);
}

void DYPlayer::setup(HardwareSerial* serial)
{
	s = serial;
	s->begin(9600);

}


void DYPlayer::init()
{
	byte cmd[] = { 0xAA, 0x1A, 0x01, 0x00 }; // EQ-Normal

	s->flush();

	sendCommand(cmd, 0x04);

	delay(100);
	VolumeMid();
	delay(100);
}

void DYPlayer::SetVolume(const byte Volume, const bool SetAsStandard /*= true*/)
{

	byte cmd[4] = { 0xAA, 0x13, 0x01, 0x00 }; // Set Volume, Specify Volume (0-30)

	cmd[3] = Volume;

	if (SetAsStandard)
		CurrentVolume = Volume;

	sendCommand(cmd, 0x04);
}

void DYPlayer::VolumeUp()
{
	if (CurrentVolume < 30)
	{
		CurrentVolume += 2;
		SetVolume(CurrentVolume);
	}
}

void DYPlayer::VolumeDown()
{
	if (CurrentVolume >= 2)
	{
		CurrentVolume -= 2;
		SetVolume(CurrentVolume);
	}
}

void DYPlayer::VolumeMid()
{
	SetVolume(15);
}

void DYPlayer::VolumeMax()
{
	SetVolume(30);
}

void DYPlayer::VolumeMin()
{
	SetVolume(5);
}

void DYPlayer::VolumeOff()
{
	SetVolume(0, false);
}

void DYPlayer::Play(const int track)
{
	byte cmd[5] = { 0xAA, 0x07, 0x02, 0x00, 0x00 };	// Play specific Song
    //command[3] = highByte(soundTrack);//snh...track HIGH bit
    //command[4] = lowByte(soundTrack);//SNL... track low bit
    byte hb = (track>>8) & 0xff;
    byte lb = track & 0xff;

    cmd[3] = hb;
	cmd[4] = lb;

	sendCommand(cmd, 0x05);
}

void DYPlayer::Stop()
{
	byte cmd[3] = { 0xAA, 0x04, 0x00 };
	sendCommand(cmd, 0x03);
}

void DYPlayer::Quiet(const bool on /* = true*/)
{
	byte cmd[3] = { 0xAA, 0x10, 0x00 };
	sendCommand(cmd, 0x03);
}

void DYPlayer::sendCommand(const byte *Command, const byte len)
{
	// Calculte Checksum
	uint8_t sum = 0;
	for (uint8_t i = 0; i < len; i++)
		sum = sum + Command[i];

	// Write Commeand
	s->write(Command, len);
	// Write Checksum
	s->write(sum);
	s->flush();

	// Delay needed between successive commands
	delay(100);
}